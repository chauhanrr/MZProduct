package com.product.qa.pages;

import com.product.qa.base.TestBase;

public class EventsPage extends TestBase {

}
