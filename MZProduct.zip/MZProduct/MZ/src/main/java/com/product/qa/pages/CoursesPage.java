package com.product.qa.pages;

import java.util.List;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.product.qa.base.TestBase;

public class CoursesPage extends TestBase {

	@FindBy(xpath = "//li[@class='nav-item linkmenu']//a[text()='Courses']")
	WebElement CoursesLink;
	
	@FindBy(xpath = "//div[@class='section-title']//h2[text()='Courses']")
	WebElement Courseslabel;
	
	@FindBy(xpath = "//div[@class='section-title']/following::h2[text()='Filters'][2]")
	WebElement FiltersTitle;
	
	@FindBy(xpath="(//div[@id='accordion']//li//a[text()='Business'])[2]")
	WebElement BussinessLink;
	
	@FindBy(xpath="(//div[@id='accordion']//li//a[text()='Design'])[2]")
	WebElement DesignLink;
	
	@FindBy(xpath = "//div[@class='section-title']//h2[text()='Blogs']")
	WebElement BlogsTitle;
	
	@FindBy(xpath = "//div//p[text()='No Courses Found']")
	WebElement LinkDetails;
	
	@FindBy(xpath = "//div[@class='blog-info']//a[text()='View']")
	WebElement ViewLink;
	
	@FindBy(xpath = "//p[text()='Get access to all videos in the library']/following::a[text()='Access Course']")
	WebElement AccessCourse;
	
	public CoursesPage() {
		//initializing WebElement
		PageFactory.initElements(driver ,this);
	}
	
	
	public boolean VerifyCoursesLabel() {
		return Courseslabel.isDisplayed();
	}
	
	
	
	public CoursesPage ValidateFilterLinks() throws InterruptedException {
		  
		List<WebElement>  FilterLinks = driver.findElements(By.xpath("//div[@id='accordion']//li//a"));
		  System.out.println(FilterLinks.size());
		
		  for(int i=8; i<FilterLinks.size();i++) {
		         FilterLinks.get(i).click();
		         Thread.sleep(5000);
		         //System.out.println(i+"--" + LinkDetails);
		         //System.out.println(i+"--" + LinkDetails.toString().contains("Proxy"));
				
		         if(!LinkDetails.toString().contains("Proxy") && LinkDetails.getText().equalsIgnoreCase("No Courses Found") ) {
		        	 //Thread.sleep(5000);
		        	 Assert.assertTrue(LinkDetails.isDisplayed(),"Courses Found");
		        	 System.out.println("Course Not Found");
		         }
		         else{
			
		        	 //List<WebElement> ListViewlink= driver.findElements(By.xpath("//div[@class='blog-info']//a[text()='View']"));
		        	 //Thread.sleep(5000);
			
		        	 Assert.assertTrue(ViewLink.isDisplayed(),"No Courses Found");
		        	 System.out.println("Courses Found");
			
		         }	
		  }
		return new CoursesPage();
		
		}
	
	public CoursesPage VerifyCoursesLink() throws InterruptedException {
		List<WebElement> ListViewlink= driver.findElements(By.xpath("//div[@class='blog-info']//a[text()='View']"));
		for(int j=0; j<ListViewlink.size();j++) {
			ListViewlink.get(j).click();
			Thread.sleep(7000);
			Assert.assertTrue(AccessCourse.isDisplayed(),"No Courses Found");
			
		}
		return new CoursesPage();
	}
	
}
